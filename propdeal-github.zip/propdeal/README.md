# PropDeal

A modern property listing site with login, favourites and seller uploads.

## What's inside

| Path | What it is |
|---|---|
| `index.html` | Full site in one file: login, then property listings. No server needed. |
| `login.html` | Login page only. |
| `backend-mysql/` | Optional version that saves users and properties in MySQL (Node.js + Express). |

## Option 1: Standalone (easiest)

Open `index.html` in a browser, or turn on **GitHub Pages** (Settings → Pages → Branch `main`) to put it online.

Demo accounts (use the "Use Seller / Buyer / Admin" buttons on the login screen):

| Role | Email | Password |
|---|---|---|
| Seller | seller@example.com | Seller@1234 |
| Buyer | buyer@example.com | Buyer@1234 |
| Admin | admin@example.com | Admin@1234 |

Data is stored in the browser (localStorage). Sellers can add and delete listings; everyone can favourite.

## Option 2: With MySQL

Needs Node.js and MySQL (for example XAMPP).

1. Import `backend-mysql/schema.sql` into MySQL (phpMyAdmin → Import).
2. Copy `backend-mysql/.env.example` to `backend-mysql/.env` and fill in your MySQL password.
3. In the `backend-mysql` folder run:
   ```bash
   npm install
   npm run seed
   npm start
   ```
4. Open http://localhost:3000 and sign in with a demo account.

Note: GitHub Pages cannot run the backend. Host it on a Node service such as Render or Railway.
